package LaFiProject;

public class getDday {

	private static String[] GetUserDday(String UserNum) {
		String url = "getdday";
		String returntext = "";
		String day[] = new String[0];

		String Get = "Num="+UserNum;

		String b = ""; 
		b = LinkPHP.getCon(url, Get);

		if(b.length() != 0) {
			String Num[] = b.split("/");
			day = Num;
		}else {
			day[0] = "fail";
		}
		return day;
	}
	
	static String[] getDday(String userNum) {
		String getMemo[] = GetUserDday(userNum);
		return getMemo;
	}
	
	public static void main(String args[]) {
		String b[] = GetUserDday("1");

		System.out.println("hello");
		for(int i = 0; i < b.length; i++) {
			System.out.println(b[i]);
		}
		
	}
}